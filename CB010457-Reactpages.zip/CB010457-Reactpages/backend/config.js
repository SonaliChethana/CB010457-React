module.exports = {
    host: 'localhost',
    user: 'root',  // Change to your MySQL user
    password: '',  // Change to your MySQL password
    database: 'springfield',  // Change to your MySQL database
  };