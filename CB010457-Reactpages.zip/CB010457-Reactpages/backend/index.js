const express = require('express');
const bodyParser = require('body-parser');
const dbConfig = require('./config.js');
const mysql = require('mysql');
const cors = require('cors'); // Import the CORS middleware
const nodemailer = require('nodemailer');

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors()); // Enable CORS for all routes

// Middleware
app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection(dbConfig);

connection.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// email service begin 
const transporter = nodemailer.createTransport({
  port: 465,               // true for 465, false for other ports
  host: "smtp.gmail.com",
  auth: {
    user: 'myemailm207@gmail.com',
    pass: 'qekn fdbt gbbs utwv',
  },
  secure: true,
  });
  // qekn fdbt gbbs utwv

// API endpoint to send email
app.post('/send-email', (req, res) => {
  const { to, subject, text } = req.body;

  const mailOptions = {
    from: 'myemailm207@gmail.com',
    to,
    subject,
    text,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.status(500).send('Error sending email');
    } else {
      console.log('Email sent: ' + info.response);
      res.status(200).send('Email sent');
  }
  });
});


// CRUD Operations

// Create a new user
app.post('/users', (req, res) => {
    const { name, email } = req.body;
    const sql = 'INSERT INTO users (name, email) VALUES (?, ?)';
    connection.query(sql, [name, email], (err, result) => {
      if (err) {
        return res.status(500).send(err);
      }
      res.status(201).send(`User added with ID: ${result.insertId}`);
  });
  });

// Create a new adoption request
app.post('/adoptions', (req, res) => {
  const { name, email, petName } = req.body;
  const sql = 'INSERT INTO adoptions (name, email, petName) VALUES (?, ?, ?)';
  connection.query(sql, [name, email, petName], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(201).send(`Adoption request added with ID: ${result.insertId}`);
  });
});

// Create a new pet
app.post('/pets', (req, res) => {
  const { petName, age, breed, description } = req.body;
  
  // Check if all required fields are provided
  if (!petName || !age || !breed || !description) {
    return res.status(400).send('All fields are required');
  }

  const sql = 'INSERT INTO petlist (petName, age, breed, description) VALUES (?, ?, ?, ?)';
  connection.query(sql, [petName, age, breed, description], (err, result) => {
    if (err) {
      console.error('Database Error:', err); // Log the error for debugging
      return res.status(500).send('Error saving pet data'); // Return a generic error message
    }
    res.status(201).send(`Pet added with ID: ${result.insertId}`);
  });
});


  // Read all users
app.get('/users', (req, res) => {
    const sql = 'SELECT * FROM users';
    connection.query(sql, (err, results) => {
      if (err) {
        return res.status(500).send(err);
      }
      res.status(200).json(results);
  });
  });

// Read all adoption requests
app.get('/adoptions', (req, res) => {
  const sql = 'SELECT * FROM adoptions';
  connection.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(200).json(results);
  });
});

// Read all pets
app.get('/pets', (req, res) => {
  const sql = 'SELECT * FROM petlist';
  connection.query(sql, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.status(200).json(results);
  });
});



  // Read a single user by ID
app.get('/users/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM users WHERE id = ?';
    connection.query(sql, [id], (err, result) => {
      if (err) {
        return res.status(500).send(err);
      }
      if (result.length === 0) {
        return res.status(404).send('User not found');
      }
      res.status(200).json(result[0]);
  });
  });

  // Read a single adoption request by ID
app.get('/adoptions/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM adoptions WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.length === 0) {
      return res.status(404).send('Adoption request not found');
    }
    res.status(200).json(result[0]);
  });
});


  // Update a user by ID
app.put('/users/:id', (req, res) => {
    const { id } = req.params;
    const { name, email } = req.body;
    const sql = 'UPDATE users SET name = ?, email = ? WHERE id = ?';
    connection.query(sql, [name, email, id], (err, result) => {
      if (err) {
        return res.status(500).send(err);
      }
      if (result.affectedRows === 0) {
        return res.status(404).send('User not found');
      }
      res.status(200).send('User updated successfully');
  });
  });

  // Update an adoption request by ID
app.put('/adoptions/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, petName } = req.body;
  const sql = 'UPDATE adoptions SET name = ?, email = ?, petName = ? WHERE id = ?';
  connection.query(sql, [name, email, petName, id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Adoption request not found');
    }
    res.status(200).send('Adoption request updated successfully');
  });
});

// Update a pet by ID
app.put('/pets/:id', (req, res) => {
  const { id } = req.params;
  const { petName, age, breed, description } = req.body;

  const sql = 'UPDATE petlist SET petName = ?, age = ?, breed = ?, description = ? WHERE id = ?';
  connection.query(sql, [petName, age, breed, description, id], (err, result) => {
    if (err) {
      console.error('Database Error:', err); // Log the error for debugging
      return res.status(500).send('Error updating pet data'); // Return a generic error message
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Pet not found');
    }
    res.status(200).send('Pet updated successfully');
  });
});



  // Delete a user by ID
app.delete('/users/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM users WHERE id = ?';
    connection.query(sql, [id], (err, result) => {
      if (err) {
        return res.status(500).send(err);
      }
      if (result.affectedRows === 0) {
        return res.status(404).send('User not found');
      }
      res.status(200).send('User deleted successfully');
  });
  });

  // Delete an adoption request by ID
app.delete('/adoptions/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM adoptions WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Adoption request not found');
    }
    res.status(200).send('Adoption request deleted successfully');
  });
});

// Delete a pet by ID
app.delete('/pets/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM petlist WHERE id = ?';
  connection.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Pet not found');
    }
    res.status(200).send('Pet deleted successfully');
  });
});

  // Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
  });

