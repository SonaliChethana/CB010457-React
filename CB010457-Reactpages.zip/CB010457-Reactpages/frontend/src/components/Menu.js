import React from 'react'
import '../assets/css/menu.css'

export default function Menu() {
  return (
    <ul>
      <li><a href="/">Home</a>  </li>
      <li className="dropdown"><a href="#" className="dropbtn">Pets</a>
        <div className="dropdown-content">
          <a href="/availablePets">Available pets</a>
          <a href="/adopt">Adopt Pets</a>
          <a href="/see-all-cityDetail">See All </a>
        </div>
      </li>

      {/* drop menu for News */}
      <li className="dropdown"> <a href="javascript:void(0)" classNameName="dropbtn">Services</a>
        <div className="dropdown-content">
                
        </div>
      </li>
  
      <li className="dropdown">
        <a href="javascript:void(0)" className="dropbtn">Users</a>
        <div className="dropdown-content">
          <a href="/users">User management</a>
        </div>
      </li>
      <li><a target='blank' href="http://localhost/Springfield/index.php">Upload</a>  </li>
    </ul>
  )
}