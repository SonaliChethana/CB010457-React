import React from 'react'
import img1 from '../assets/images/images1.png'
import '../assets/css/header.css'


export default function Header() {
  return (
    <div className="top">
      <img className="imgl" src={img1} />
      <h1>Springfield Pet Rescue</h1>
    </div>


  )
}