import React from "react";
import '../assets/css/footer.css';

export default function Footer() {
  return <div id="footer">All rights reserved. | Privacy Policy | Terms of Service | Contact Us  </div>;
}