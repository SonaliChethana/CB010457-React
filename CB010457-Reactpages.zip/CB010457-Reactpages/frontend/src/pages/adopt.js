import React, { useState, useEffect } from "react";
import axios from "axios";
import "../assets/css/adopt.css";

const Adopt = () => {
  const [adoptions, setAdoptions] = useState([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [petName, setPetName] = useState("");
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchAdoptions();
  }, []);

  // Fetch all adoption requests from backend
  const fetchAdoptions = async () => {
    try {
      const response = await axios.get("http://localhost:3001/adoptions");
      setAdoptions(response.data);
    } catch (error) {
      console.error("Error fetching adoption requests", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editId === null) {
      // Add new adoption request
      try {
        await axios.post("http://localhost:3001/adoptions", {
          name,
          email,
          petName,
        });
        fetchAdoptions(); // Refresh adoption list
      } catch (error) {
        console.error("Error adding adoption request", error);
      }
    } else {
      // Update existing adoption request
      try {
        await axios.put(`http://localhost:3001/adoptions/${editId}`, {
          name,
          email,
          petName,
        });
        fetchAdoptions(); // Refresh adoption list
        setEditId(null); // Reset edit mode
      } catch (error) {
        console.error("Error updating adoption request", error);
      }
    }

    setName("");
    setEmail("");
    setPetName("");
  };

  // Handle delete adoption request
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/adoptions/${id}`);
      fetchAdoptions(); // Refresh adoption list
    } catch (error) {
      console.error("Error deleting adoption request", error);
    }
  };

  // Handle edit adoption request
  const handleEdit = (adoption) => {
    setName(adoption.name);
    setEmail(adoption.email);
    setPetName(adoption.petName);
    setEditId(adoption.id); // Set edit mode
  };

  return (
    <div className="adopt-container">
      <h2>Adopt a Pet</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Pet Name"
          value={petName}
          onChange={(e) => setPetName(e.target.value)}
          required
        />
        <button className="submit-btn" type="submit">
          {editId !== null ? "Update Request" : "Submit Request"}
        </button>
      </form>

      <h3>Adoption Requests</h3>
      {adoptions.length === 0 ? (
        <p>No adoption requests available</p>
      ) : (
        <table className="adoption-table">
          <thead>
            <tr>
              <th>Your Name</th>
              <th>Email</th>
              <th>Pet Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {adoptions.map((adoption) => (
              <tr key={adoption.id}>
                <td>{adoption.name}</td>
                <td>{adoption.email}</td>
                <td>{adoption.petName}</td>
                <td>
                  <button onClick={() => handleEdit(adoption)}>Edit</button>
                  <button onClick={() => handleDelete(adoption.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Adopt;
