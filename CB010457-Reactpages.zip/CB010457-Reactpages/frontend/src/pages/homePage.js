import React from "react";
import "../assets/css/front.css";

const Home = () => {
  return (
			<section id="welcome-hero" class="welcome-hero">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center">
							<div class="header-text">
								<h2>Hi <span>,</span> Welcome to <br />Springfield Pet Rescue <span>.</span></h2>
								<p>Join us in making a difference in the lives of stray dogs through rescue, rehabilitation, and rehoming.</p>
							</div>
						</div>
					</div>
				</div>

			</section>

  )
}
export default Home;
