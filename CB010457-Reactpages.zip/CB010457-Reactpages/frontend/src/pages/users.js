import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/home.css';

const Users =()=>{
    const [users, setUsers] = useState([]);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [editId, setEditId] = useState(null);

    useEffect(() => {
        fetchUsers();
      }, []);

    // Fetch all users from backend
  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editId === null) {
      // Add new user
      try {
        await axios.post('http://localhost:3001/users', { name, email });
        fetchUsers(); // Refresh user list
      } catch (error) {
        console.error('Error adding user', error);
      }
    } else {
      // Update existing user
      try {
        await axios.put(`http://localhost:3001/users/${editId}`, { name, email });
        fetchUsers(); // Refresh user list
        setEditId(null); // Reset edit mode
      } catch (error) {
        console.error('Error updating user', error);
      }
    }

    setName('');
    setEmail('');
  };

    // Handle delete user
    const handleDelete = async (id) => {
        try {
          await axios.delete(`http://localhost:3001/users/${id}`);
          fetchUsers(); // Refresh user list
        } catch (error) {
          console.error('Error deleting user', error);
        }
      };

      
  // Handle edit user
  const handleEdit = (user) => {
    setName(user.name);
    setEmail(user.email);
    setEditId(user.id); // Set edit mode
  };

  /*
  //function to send email
  const handleEmail=async (email, name)=>{
    // const emailHtml = await render(<p>hello</p>);
    const options = {
      to: email,
      subject: 'Welcome to Team',
      text: Hi ${name},\n\nWelcome to Awesome Company! We\'re excited to have you on board.\n\nIf you have any questions or need assistance, feel free to reach out. We\'re here to help!\n\nBest regards,\nJane Doe\nCustomer Success Manager\nAwesome Company,
    };
    
    // await transporter.sendMail(options);
    try {
        // Make a POST request to your backend
    const response = await fetch('http://localhost:3001/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(options),
    });

    if (response.ok) {
      alert('Email sent successfully!');
    } else {
      alert('Failed to send email');
    }
    } catch (error) {
      console.error('Error deleting user', error);
 }
 }
*/

    
  return (
    <div className="container">
      <h2>User Management</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <button className="submit-btn" type="submit">
          {editId !== null ? 'Update User' : 'Add User'}
        </button>
      </form>

      <h3>User List</h3>
      {users.length === 0 ? (
        <p>No users available</p>
      ) : (
        <table className="user-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>
                  <button onClick={() => handleEdit(user)}>Edit</button>
                  <button onClick={() => handleDelete(user.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

}
export default Users;
