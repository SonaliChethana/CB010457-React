import React, { useState, useEffect } from "react";
import axios from "axios";
import petImage1 from "../assets/images/pet1.png"; // Sample pet images
import petImage2 from "../assets/images/pet2.jpg"; // You can replace them with real pet images
import "../assets/css/availablePets.css";

const AvailablePets = () => {
  const [pets, setPets] = useState([]);
  const [petName, setPetName] = useState("");
  const [age, setAge] = useState("");
  const [breed, setBreed] = useState("");
  const [description, setDescription] = useState("");
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchPets();
  }, []);

  // Fetch all pets from backend
  const fetchPets = async () => {
    try {
      const response = await axios.get("http://localhost:3001/pets");
      setPets(response.data);
    } catch (error) {
      console.error("Error fetching pets", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const petData = {
      petName,
      age,
      breed,
      description, // Removed photo from here
    };

    if (editId === null) {
      // Add new pet
      try {
        await axios.post("http://localhost:3001/pets", petData);
        fetchPets(); // Refresh pet list
      } catch (error) {
        console.error("Error adding pet", error);
      }
    } else {
      // Update existing pet
      try {
        await axios.put(`http://localhost:3001/pets/${editId}`, petData);
        fetchPets(); // Refresh pet list
        setEditId(null); // Reset edit mode
      } catch (error) {
        console.error("Error updating pet", error);
      }
    }

    // Clear the form fields
    setPetName("");
    setAge("");
    setBreed("");
    setDescription("");
  };

  // Handle delete pet
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/pets/${id}`);
      fetchPets(); // Refresh pet list
    } catch (error) {
      console.error("Error deleting pet", error);
    }
  };

  // Handle edit pet
  const handleEdit = (pet) => {
    setPetName(pet.petName);
    setAge(pet.age);
    setBreed(pet.breed);
    setDescription(pet.description);
    setEditId(pet.id); // Set edit mode
  };

  return (
    <div className="available-pets-container">
      <h1>Available Pets for Adoption</h1>
      <p>
        Welcome to Springfield Pet Rescue! We are dedicated to finding forever homes for these lovely animals. Below are some of the adorable pets waiting to be adopted.
      </p>

      <div className="pets-list">
        <div className="pet-card">
          <img src={petImage1} alt="Cute dog" className="pet-image" />
          <h2>Buddy</h2>
          <p>Age: 2 years</p>
          <p>Breed: Labrador</p>
          <p>Buddy is a playful and loving dog looking for a caring family.</p>
        </div>

        <div className="pet-card">
          <img src={petImage2} alt="Adorable cat" className="pet-image" />
          <h2>Mittens</h2>
          <p>Age: 1 year</p>
          <p>Breed: Domestic Short Hair</p>
          <p>Mittens is a sweet and calm cat ready to fill your home with love.</p>
        </div>
      </div>

      <h2>Add a New Pet</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Pet Name"
          value={petName}
          onChange={(e) => setPetName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Breed"
          value={breed}
          onChange={(e) => setBreed(e.target.value)}
          required
        />
        <textarea
          className="input-field"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <button className="submit-btn" type="submit">
          {editId !== null ? "Update Pet" : "Add Pet"}
        </button>
      </form>

      <h3>Available Pets</h3>
      {pets.length === 0 ? (
        <p>No pets available</p>
      ) : (
        <table className="pets-table">
          <thead>
            <tr>
              <th>Pet Name</th>
              <th>Age</th>
              <th>Breed</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pets.map((pet) => (
              <tr key={pet.id}>
                <td>{pet.petName}</td>
                <td>{pet.age}</td>
                <td>{pet.breed}</td>
                <td>{pet.description}</td>
                <td>
                  <img src={pet.photo} alt={pet.petName} className="table-photo" />
                </td>
                <td>
                  <button onClick={() => handleEdit(pet)}>Edit</button>
                  <button onClick={() => handleDelete(pet.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AvailablePets;
