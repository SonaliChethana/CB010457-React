import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/homePage";
import Layout from "./components/Layout";
import AvailablePets from "./pages/availablePets";
import Users from "./pages/users";
import Adopt from "./pages/adopt";
import CityDetail from "./pages/cityDetail";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route key={"Layout"} path="/" element={<Layout />}>
          <Route key={"homePage"} path="/" element={<Home />} />
          <Route key={"availablePets"} path="/availablePets" element={<AvailablePets />} />
          <Route key={"users"} path="/users" element={<Users />} />
          <Route key={"adopt"} path="/adopt" element={<Adopt />} />
          <Route key={"cityDetail"} path="/see-all-cityDetail" element={<CityDetail />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
